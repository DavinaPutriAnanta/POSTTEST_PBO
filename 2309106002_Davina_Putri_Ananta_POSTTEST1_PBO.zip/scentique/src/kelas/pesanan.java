package kelas;


class Pesanan {
    String idPesanan, idPelanggan, idAdmin, status, tanggalPesanan;
    double totalHarga;
    
    public Pesanan(String idPesanan, String idPelanggan, String idAdmin, String status, String tanggalPesanan, double totalHarga) {
        this.idPesanan = idPesanan;
        this.idPelanggan = idPelanggan;
        this.idAdmin = idAdmin;
        this.status = status;
        this.tanggalPesanan = tanggalPesanan;
        this.totalHarga = totalHarga;
    }
}
