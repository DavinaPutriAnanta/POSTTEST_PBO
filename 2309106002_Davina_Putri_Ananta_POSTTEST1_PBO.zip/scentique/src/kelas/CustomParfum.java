package kelas;


class CustomParfum {
    String idCustom, idPelanggan, kelasParfum, notesParfum;
    double hargaCustom;
    
    public CustomParfum(String idCustom, String idPelanggan, String kelasParfum, String notesParfum, double hargaCustom) {
        this.idCustom = idCustom;
        this.idPelanggan = idPelanggan;
        this.kelasParfum = kelasParfum;
        this.notesParfum = notesParfum;
        this.hargaCustom = hargaCustom;
    }
}