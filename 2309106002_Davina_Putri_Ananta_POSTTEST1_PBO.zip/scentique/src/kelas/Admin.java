package kelas;


class Admin {
    String idAdmin, nama, email, password;
    
    public Admin(String idAdmin, String nama, String email, String password) {
        this.idAdmin = idAdmin;
        this.nama = nama;
        this.email = email;
        this.password = password;
    }
}