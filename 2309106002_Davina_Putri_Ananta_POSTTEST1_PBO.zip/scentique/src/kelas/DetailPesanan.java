package kelas;


class DetailPesanan {
    String idDetailPesanan, idPesanan, idParfum, idCustomParfum;
    int jumlah;
    double subtotal;
    
    public DetailPesanan(String idDetailPesanan, String idPesanan, String idParfum, String idCustomParfum, int jumlah, double subtotal) {
        this.idDetailPesanan = idDetailPesanan;
        this.idPesanan = idPesanan;
        this.idParfum = idParfum;
        this.idCustomParfum = idCustomParfum;
        this.jumlah = jumlah;
        this.subtotal = subtotal;
    }
}