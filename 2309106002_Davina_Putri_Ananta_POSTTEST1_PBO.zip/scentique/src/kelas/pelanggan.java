package kelas;


class Pelanggan {
    String idPelanggan, nama, email, password, alamat, noTelp;
    
    public Pelanggan(String idPelanggan, String nama, String email, String password, String alamat, String noTelp) {
        this.idPelanggan = idPelanggan;
        this.nama = nama;
        this.email = email;
        this.password = password;
        this.alamat = alamat;
        this.noTelp = noTelp;
    }
}
