package kelas;

public class Parfum {
    public String idParfum;
    public String namaParfum;
    public double hargaParfum;
    public int stok;

    public Parfum(String idParfum, String namaParfum, double hargaParfum, int stok) {
        this.idParfum = idParfum;
        this.namaParfum = namaParfum;
        this.hargaParfum = hargaParfum;
        this.stok = stok;
    }
}